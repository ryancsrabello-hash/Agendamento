-- Instituto Lins Rabello — sincronização do estado do aplicativo
-- Execute este arquivo no Supabase: SQL Editor > New query > Run.

create table if not exists public.app_state (
  id text primary key,
  data jsonb not null default '{"appointments":[],"expenses":[],"logs":[],"blocks":[]}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.app_state enable row level security;

drop policy if exists "app_state_select_public" on public.app_state;
create policy "app_state_select_public"
on public.app_state for select
to anon, authenticated
using (true);

drop policy if exists "app_state_insert_public" on public.app_state;
create policy "app_state_insert_public"
on public.app_state for insert
to anon, authenticated
with check (true);

drop policy if exists "app_state_update_public" on public.app_state;
create policy "app_state_update_public"
on public.app_state for update
to anon, authenticated
using (true)
with check (true);

drop policy if exists "app_state_delete_public" on public.app_state;
create policy "app_state_delete_public"
on public.app_state for delete
to anon, authenticated
using (true);

grant select, insert, update, delete on table public.app_state to anon, authenticated;

-- Ativa atualizações em tempo real sem falhar caso a tabela já esteja adicionada.
do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'app_state'
  ) then
    alter publication supabase_realtime add table public.app_state;
  end if;
end $$;
